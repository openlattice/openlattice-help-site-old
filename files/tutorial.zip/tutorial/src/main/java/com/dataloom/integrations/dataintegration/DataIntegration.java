package com.dataloom.integrations.dataintegration;

import java.io.File;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.UUID;

import com.kryptnostic.shuttle.Flight;
import com.kryptnostic.shuttle.MissionControl;
import com.kryptnostic.shuttle.Shuttle;
import org.apache.olingo.commons.api.edm.FullQualifiedName;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import retrofit2.Retrofit;

public class DataIntegration {
    // Logger is used to output useful debugging messages to the console
    private static final Logger logger = LoggerFactory.getLogger( DataIntegration.class );

    // Entity Set Details
    public static String            PEOPLE_ENTITY_SET_NAME = "samplejailsubjects";
    public static FullQualifiedName PEOPLE_ENTITY_SET_TYPE = new FullQualifiedName( "sample.person" );
    public static FullQualifiedName PEOPLE_ENTITY_SET_KEY1  = new FullQualifiedName( "general.firstname" );
    public static FullQualifiedName PEOPLE_ENTITY_SET_KEY2  = new FullQualifiedName( "general.lastname" );
    public static String            PEOPLE_ALIAS           = "people";

    public static String            BOOKINGS_ENTITY_SET_NAME = "samplejailbookings";
    public static FullQualifiedName BOOKINGS_ENTITY_SET_TYPE = new FullQualifiedName( "sample.bookings" );
    public static FullQualifiedName BOOKINGS_ENTITY_SET_KEY1  = new FullQualifiedName( "publicsafety.datebooked" );
    public static FullQualifiedName BOOKINGS_ENTITY_SET_KEY2  = new FullQualifiedName( "publicsafety.datereleased" );
    public static String            BOOKINGS_ALIAS           = "bookings";

    public static String            WAS_BOOKED_IN_ENTITY_SET_NAME = "samplejailsubjectappearsin";
    public static FullQualifiedName WAS_BOOKED_IN_ENTITY_SET_TYPE = new FullQualifiedName( "sample.subjectappearsin" );
    public static FullQualifiedName WAS_BOOKED_IN_ENTITY_SET_KEY  = new FullQualifiedName( "publicsafety.bookingid" );
    public static String            WAS_BOOKED_IN_ALIAS           = "appearsin";

    // Properties
    public static FullQualifiedName LAST_NAME_FQN    = new FullQualifiedName( "general.lastname" );
    public static FullQualifiedName FIRST_NAME_FQN   = new FullQualifiedName( "general.firstname" );
    public static FullQualifiedName HOME_ADDRESS_FQN = new FullQualifiedName( "general.homeaddress" );
    public static FullQualifiedName RACE_FQN         = new FullQualifiedName( "general.race" );
    public static FullQualifiedName DOB_FQN          = new FullQualifiedName( "general.dob" );

    public static FullQualifiedName DATE_BOOKED_FQN          = new FullQualifiedName( "publicsafety.datebooked" );
    public static FullQualifiedName BOOKING_ID_FQN       = new FullQualifiedName( "publicsafety.bookingid" );
    public static FullQualifiedName DATE_RELEASED_FQN      = new FullQualifiedName( "publicsafety.datereleased" );

    public static void main( String[] args ) throws InterruptedException {
        
        // Get CSV path, username, and password
        final String path = args[0];
        final String username = args[1];
        final String password = args[2];

        // Get jwtToken to verify data integrator has write permissions to dataset
        final String jwtToken = MissionControl.getIdToken( username, password );
        logger.info( "Using the following idToken: Bearer {}", jwtToken );

        // Configure Spark to load and read your datasource
        final SparkSession sparkSession = MissionControl.getSparkSession();
        Dataset<Row> payload = sparkSession
                .read()
                .format( "com.databricks.spark.csv" )
                .option( "header", "true" )
                .load( path );

        // Each flight stores data from 1 table or CSV
        // Add each flight to flights to integrate data from multiple CSVs or tables
        Map<Flight, Dataset<Row>> flights = Maps.newHashMap();
        Flight flight = Flight.newFlight()
                .createEntities()

                .addEntity( PEOPLE_ALIAS )
                .ofType( PEOPLE_ENTITY_SET_TYPE )
                .to( PEOPLE_ENTITY_SET_NAME )
                .key( PEOPLE_ENTITY_SET_KEY1, PEOPLE_ENTITY_SET_KEY2 )
                .addProperty( LAST_NAME_FQN )
                .value( row -> row.getAs( "Last Name" ) ).ok()
                .addProperty( FIRST_NAME_FQN )
                .value( row -> row.getAs( "First Name" ) ).ok()
                .addProperty( HOME_ADDRESS_FQN )
                .value( row -> row.getAs( "Address" ) ).ok()
                .addProperty( RACE_FQN )
                .value( row -> row.getAs( "Race" ) ).ok()
                .addProperty( DOB_FQN )
                .value( row -> standardizeDate2( row.getAs( "DOB" ) ) ).ok().ok()

                .addEntity( BOOKINGS_ALIAS )
                .ofType( BOOKINGS_ENTITY_SET_TYPE )
                .to( BOOKINGS_ENTITY_SET_NAME )
                .key( BOOKINGS_ENTITY_SET_KEY1, BOOKINGS_ENTITY_SET_KEY2 )
                .addProperty( DATE_BOOKED_FQN )
                .value( row -> standardizeDate( row.getAs( "Date Booked" ) ) ).ok()
                .addProperty( DATE_RELEASED_FQN )
                .value( row -> standardizeDate( row.getAs( "Date Released" ) ) ).ok()

                .ok().ok()
                .createAssociations()

                .addAssociation( WAS_BOOKED_IN_ALIAS )
                .ofType( WAS_BOOKED_IN_ENTITY_SET_TYPE )
                .to( WAS_BOOKED_IN_ENTITY_SET_NAME )
                .key( WAS_BOOKED_IN_ENTITY_SET_KEY )
                .fromEntity( PEOPLE_ALIAS )
                .toEntity( BOOKINGS_ALIAS )
                .addProperty( BOOKING_ID_FQN )
                .value( row -> row.getAs( "Booking ID" ) ).ok().ok().ok()
                .done();

        // At this point, your flight contains 1 table's worth of data
        // If you want to integrate more tables, create another flight (flight2) and
        // add the flight to flights
        flights.put( flight, payload );

        // Send your flight plan to Shuttle and complete your integration!
        Shuttle shuttle = new Shuttle( Environment.PRODUCTION, jwtToken );
        shuttle.launch( flights );
    }

    // CUSTOM FUNCTIONS DEFINED BELOW

    public static String standardizeDate( Object myDate ) {
        if (myDate != null && !myDate.equals("")) {
            String d = myDate.toString();
            FormattedDateTime date = new FormattedDateTime( d, null, "yyyy-dd-MM", "");
            return date.getDateTime();
        }
        return null;
    }

    public static String standardizeDate2( Object myDate ) {
        if (myDate != null && !myDate.equals("")) {
            String d = myDate.toString();
            FormattedDateTime date = new FormattedDateTime( d, null, "yyyy-MM-dd", "");
            return date.getDateTime();
        }
        return null;
    }
}
