./exampleorg-v0.0.1/bin/exampleorg ./crime_index.csv test@example.com examplepassword
