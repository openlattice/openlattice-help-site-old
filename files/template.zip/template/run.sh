# Change to name of your csv file and organization account's login credentials
./exampleorg-v0.0.1/bin/exampleorg ./crime_index.csv test@example.com examplepassword
