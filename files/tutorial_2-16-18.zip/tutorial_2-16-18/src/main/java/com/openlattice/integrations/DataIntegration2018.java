package com.openlattice.integrations;


import com.openlattice.client.RetrofitFactory;
import com.openlattice.edm.EdmApi;
import java.util.Map;
import com.openlattice.shuttle.Flight;
import com.openlattice.shuttle.Shuttle;
import com.openlattice.shuttle.dates.DateTimeHelper;
import com.openlattice.shuttle.dates.TimeZones;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import retrofit2.Retrofit;
import com.openlattice.shuttle.payload.Payload;
import com.openlattice.shuttle.payload.SimplePayload;

import java.util.Map;


public class DataIntegration2018 {
    // Logger is used to output useful debugging messages to the console
    private static final Logger logger = LoggerFactory.getLogger( DataIntegration2018.class );

    // CUSTOM FUNCTION DEFINED BELOW
    //Parse dates correctly, from input string columns. One can select timezone, here shown for New York.
    private static final DateTimeHelper dtHelper = new DateTimeHelper(TimeZones.America_NewYork, "YYYYMMdd");
    private static final DateTimeHelper bdHelper = new DateTimeHelper(TimeZones.America_NewYork, "YYYY-MM-dd");


    public static void main( String[] args ) throws InterruptedException {

        // Get CSV path - we can name it anything we want, here it is named "csvpath"
        final String csvpath = args[0];

        // Get jwtToken to verify data integrator has write permissions to dataset
        final String jwtToken = args[1];
        logger.info( "Using the following idToken: Bearer {}", jwtToken );

        // Configure OpenLattice's Payload function to load and read your datasource
        SimplePayload payload  = new SimplePayload( csvpath);

        Retrofit retrofit = RetrofitFactory.newClient( RetrofitFactory.Environment.PRODUCTION, () -> jwtToken );
        EdmApi edm = retrofit.create( EdmApi.class );

        // Each flight stores data from 1 table or CSV
        // Add each flight to flights to integrate data from multiple CSVs or tables
        Map<Flight, Payload> flights = new java.util.HashMap<>( 1 );

        //you are creating a new java object of type "Flight", which we will call "csvflight"
        Flight flight = Flight.newFlight()
                .createEntities()
                    .addEntity( "PEOPLE_ALIAS" )      //variable name within flight. Doesn't have to match anything anywhere else.
                        .to( "PEOPLE_ENTITY_SET_NAME" )       //Replace with the name of your entity dataset you created in step 2 of tutorial, 'Integratons Part I'.
                            .addProperty( "LAST_NAME_FQN", "LAST_NAME_COL" )
                            .addProperty( "FIRST_NAME_FQN", "FIRST_NAME_COL" )
                            .addProperty( "RACE_FQN", "RACE_COL" )
                            .addProperty( "DOB_FQN")
                                .value( row -> bdHelper.parse( row.getAs( "DOB" ) ) ) .ok()
                        .endEntity()
                    .addEntity( "ADDRESS_ALIAS" )
                            .to( "ADDRESS_ENTITY_SET_NAME" )
                            .addProperty( "STREET_ADDRESS_FQN", "ADDRESS_COL" )
                            .endEntity()
                    .addEntity( "BOOKINGS_ALIAS" )
                            .to( "BOOKINGS_ENTITY_SET_NAME" )
                            .addProperty( "DATE_BOOKED_FQN" )
                                .value( row -> dtHelper.parse( row.getAs( "Date Booked" ) ) ).ok()
                            .addProperty( "DATE_RELEASED_FQN" )
                                .value( row -> dtHelper.parse( row.getAs( "Date Released" ) ) ).ok()
                            .endEntity()
                .endEntities()

                .createAssociations()
                    .addAssociation( "LIVES_AT_ALIAS" )
                        .to( "LIVES_AT_IN_ENTITY_SET_NAME" )
                        .fromEntity( "PEOPLE_ALIAS" )
                        .toEntity( "ADDRESS_ALIAS" )
                        .endAssociation()
                    .addAssociation( "WAS_BOOKED_IN_ALIAS" )
                        .to( "WAS_BOOKED_IN_ENTITY_SET_NAME" )
                        .fromEntity( "PEOPLE_ALIAS" )
                        .toEntity( "BOOKINGS_ALIAS" )
                        .addProperty( "BOOKING_ID_FQN", "BOOKING_ID_COL" )
                        .endAssociation()
                .endAssociations()

                    .done();

        // At this point, your flight contains 1 table's worth of data
        // If you want to integrate more tables, create another flight (flight2) and
        // add the flight to flights
        flights.put( flight, payload );     //the flight here must match the name of the flight you created on line 52.

        // Send your flight plan to Shuttle and complete your integration!
        Shuttle shuttle = new Shuttle( RetrofitFactory.Environment.PRODUCTION, jwtToken );

        shuttle.launchPayloadFlight( flights );
    }


        // OTHER CUSTOM FUNCTIONS DEFINED BELOW
        //to get first names from a column with full names (if no middle names are present)
        public static String getFirstName( Object obj ) {
          String name = obj.toString();
          String[] names = name.split( "," );
          return names[ 1 ].trim();
            }

        //to get last names from a column with full names (if no middle names are present)
        public static String getLastName( Object obj ) {
          String name = obj.toString();
          String[] names = name.split( "," );
          return names[ 0 ].trim();
        }

        //for number parsing
        public static Integer parseNumber( String num ) {
        if (num == null) return null;
        try {
            Double d = Double.parseDouble( num );
            return d.intValue();
        } catch (NumberFormatException e) {}

        try {
            Integer i = Integer.parseInt( num );
            return i;
        } catch ( NumberFormatException e) {}

        return null;
    }
}
